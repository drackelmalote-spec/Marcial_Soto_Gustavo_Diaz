import Controlador.Bodega;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BodegaTest {

    @Test
    public void testAgregar() {
        Bodega b = new Bodega();
        b.agregarProducto("A1", "Pan", 7);
        assertDoesNotThrow(() -> b.Agregar("A1", 5)); 
    }

    @Test
    public void testRestar() {
        Bodega b = new Bodega();
        b.agregarProducto("B1", "Leche", 10);
        assertDoesNotThrow(() -> b.restar("B1", 3)); 
    }

    @Test
    public void testNoPermiteStockNegativo() {
        Bodega b = new Bodega();
        b.agregarProducto("C1", "Arroz", 5);
        assertDoesNotThrow(() -> b.restar("C1", 10)); 
    }
}