For compatibility with the Eclipse IDE, the test for this module are in the `jupiter-tests` project.
