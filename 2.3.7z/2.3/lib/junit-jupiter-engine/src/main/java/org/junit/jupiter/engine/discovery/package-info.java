/**
 * Internal classes for test discovery within the JUnit Jupiter test engine.
 * Contains resolvers for Java elements.
 */

@NullMarked
package org.junit.jupiter.engine.discovery;

import org.jspecify.annotations.NullMarked;
