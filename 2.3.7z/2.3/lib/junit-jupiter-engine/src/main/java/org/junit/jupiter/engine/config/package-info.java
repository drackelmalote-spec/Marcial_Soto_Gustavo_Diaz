/**
 * Configuration specific to the JUnit Jupiter test engine.
 */

@NullMarked
package org.junit.jupiter.engine.config;

import org.jspecify.annotations.NullMarked;
