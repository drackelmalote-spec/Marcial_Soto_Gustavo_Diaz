/**
 * Test descriptors used within the JUnit Jupiter test engine.
 */

@NullMarked
package org.junit.jupiter.engine.descriptor;

import org.jspecify.annotations.NullMarked;
