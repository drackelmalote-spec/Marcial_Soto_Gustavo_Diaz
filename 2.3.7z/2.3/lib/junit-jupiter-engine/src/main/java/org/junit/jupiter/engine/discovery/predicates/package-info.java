/**
 * Internal predicate classes used by test discovery within the JUnit Jupiter test engine.
 */

@NullMarked
package org.junit.jupiter.engine.discovery.predicates;

import org.jspecify.annotations.NullMarked;
