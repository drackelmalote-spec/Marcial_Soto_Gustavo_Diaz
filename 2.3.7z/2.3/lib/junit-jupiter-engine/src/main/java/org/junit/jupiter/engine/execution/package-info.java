/**
 * Internal classes for test execution within the JUnit Jupiter test engine.
 */

@NullMarked
package org.junit.jupiter.engine.execution;

import org.jspecify.annotations.NullMarked;
