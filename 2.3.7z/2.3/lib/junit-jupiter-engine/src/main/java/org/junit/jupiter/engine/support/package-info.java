/**
 * Internal support classes for the JUnit Jupiter test engine.
 */

@NullMarked
package org.junit.jupiter.engine.support;

import org.jspecify.annotations.NullMarked;
