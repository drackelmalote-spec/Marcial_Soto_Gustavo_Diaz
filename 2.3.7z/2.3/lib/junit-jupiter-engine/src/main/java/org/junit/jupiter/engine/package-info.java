/**
 * Core package for the JUnit Jupiter test engine.
 */

@NullMarked
package org.junit.jupiter.engine;

import org.jspecify.annotations.NullMarked;
