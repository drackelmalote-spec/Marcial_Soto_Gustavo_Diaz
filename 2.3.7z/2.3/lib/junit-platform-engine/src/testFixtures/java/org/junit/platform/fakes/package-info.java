
@NullMarked
package org.junit.platform.fakes;

import org.jspecify.annotations.NullMarked;
