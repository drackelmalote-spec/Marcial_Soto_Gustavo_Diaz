/**
 * Public API for test engines.
 */

@NullMarked
package org.junit.platform.engine;

import org.jspecify.annotations.NullMarked;
