/**
 * {@link org.junit.platform.engine.ConfigurationParameters}-related support
 * classes intended to be used by test engine implementations.
 */

@NullMarked
package org.junit.platform.engine.support.config;

import org.jspecify.annotations.NullMarked;
