/**
 * Classes used by test engines to report additional data to execution
 * listeners.
 */

@NullMarked
package org.junit.platform.engine.reporting;

import org.jspecify.annotations.NullMarked;
