/**
 * Reusable data structures for test engines and their extensions.
 */

@NullMarked
package org.junit.platform.engine.support.store;

import org.jspecify.annotations.NullMarked;
