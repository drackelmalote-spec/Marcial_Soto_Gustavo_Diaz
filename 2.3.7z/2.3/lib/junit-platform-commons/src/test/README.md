For compatibility with the Eclipse IDE, the test for this module are in the `platform-tests` project.
