/**
 * Functional interfaces and support classes.
 */

@NullMarked
package org.junit.platform.commons.function;

import org.jspecify.annotations.NullMarked;
