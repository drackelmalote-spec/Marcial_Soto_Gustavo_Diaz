/**
 * Classpath scanning APIs provided by the JUnit Platform.
 */

@NullMarked
package org.junit.platform.commons.support.scanning;

import org.jspecify.annotations.NullMarked;
