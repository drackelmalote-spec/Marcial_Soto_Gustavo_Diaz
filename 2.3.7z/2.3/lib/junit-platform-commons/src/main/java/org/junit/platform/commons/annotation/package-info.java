/**
 * Common annotations for the JUnit Platform.
 */

@NullMarked
package org.junit.platform.commons.annotation;

import org.jspecify.annotations.NullMarked;
