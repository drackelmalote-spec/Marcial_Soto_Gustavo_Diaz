/**
 * IO-related interfaces and support classes
 */

@NullMarked
package org.junit.platform.commons.io;

import org.jspecify.annotations.NullMarked;
