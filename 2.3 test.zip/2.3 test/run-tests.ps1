param(
    [string]$TestClass = 'test.BodegaTest'
)

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$lib = Join-Path $ScriptRoot 'lib'
$out = Join-Path $ScriptRoot 'out'

if (-not (Test-Path $out)) {
    New-Item -ItemType Directory -Path $out | Out-Null
}

# Classpath for compilation and execution
$cp = ".;$lib\junit-4.13.2.jar;$lib\hamcrest-core-1.3.jar"

Write-Host "[run-tests] Compiling sources..."
javac -cp $cp -d $out Controlador\*.java Vista\*.java test\*.java
if ($LASTEXITCODE -ne 0) {
    Write-Error "Compilation failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}

Write-Host "[run-tests] Running tests: $TestClass"
java -cp "$out;$lib\junit-4.13.2.jar;$lib\hamcrest-core-1.3.jar" org.junit.runner.JUnitCore $TestClass
exit $LASTEXITCODE
