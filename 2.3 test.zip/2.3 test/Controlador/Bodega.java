package Controlador;

import java.util.ArrayList;

public class Bodega {
    // Clase 
    private class Producto { 
        String codigo; 
        String nombre; 
        int stock; 

        // Constructor para inicializar un producto 
        Producto(String codigo, String nombre, int stock) {
            this.codigo = codigo;
            this.nombre = nombre;
            this.stock = stock;
        }

        // Método para añadir stock al producto
        void añadirStock(int cantidad) {
            this.stock += cantidad; // Incrementa el stock con la cantidad especificada
        }

        void restarStock(int cantidad) {
            if (stock - cantidad >= 0) { // Verifica si hay suficiente stock
                this.stock -= cantidad;    //RESTA
            } else {
                
                System.out.println("-----------------------------");
                System.out.println("No hay suficiente stock para vender " + cantidad);
                System.out.println("-----------------------------");
            }
        }

        @Override
        public String toString() {
            return "Codigo : " + codigo + " | Nombre :  " + nombre + " | Stock: " + stock;
        }
    }

    
    private ArrayList<Producto> productos = new ArrayList<>(); 

    public void agregarProducto(String codigo, String nombre, int stock) {
        productos.add(new Producto(codigo, nombre, stock));         // Crea y añade un nuevo producto a la lista
        System.out.println("PRODUCTO AGREGADO!!!!"); 
    }

   
    public void Agregar(String codigo, int cantidad) {
        for (Producto p : productos) { 
            if (p.codigo.equals(codigo)) { // Busca el producto por su código
                p.añadirStock(cantidad); 
                System.out.println("STOCK ACTUALIZADO"); 
            }
        }
    }

    
    public void restar(String codigo, int cantidad) {
        for (Producto p : productos) { 
            if (p.codigo.equals(codigo)) { 
                p.restarStock(cantidad); 
                System.out.println("OPERACION REALIZADA"); 
            }
        }
    }

    
    public void listarProductos() {
        System.out.println("|||||| Inventario Almacen ||||||"); 
        for (Producto p : productos) {              // FOR EACH
            System.out.println(p); 
        }
    }
}