package Vista;

import Controlador.Bodega;
import java.util.Scanner;

public class Vista {
    private Bodega bodega; // Instancia Bodega 
    private Scanner sc; // Scanner

    // inicializo la bodega y el Scanner
    public Vista(Bodega bodega) {
        this.bodega = bodega;
        this.sc = new Scanner(System.in);
    }
 
    public void mostrarMenu() {                //bucle
        boolean salir = false;       //  bucle false

                        // bucle que se repite hasta que elige salir
        while (!salir) {
            System.out.println("\n------ ALMACÉN ------");
            System.out.println("1.- | Agregar producto");
            System.out.println("2.- | Lista");
            System.out.println("3.- | Agregar stock");
            System.out.println("4.- | Vender producto");
            System.out.println("5.- | Salir");
            System.out.println("---------------------");
            System.out.print("Opcion: ");

            // Leer la opción seleccionada por el usuario
            int op = sc.nextInt();
            sc.nextLine(); 

            switch (op) {       // el switch evalua las opciones de que elige el usuario
                case 1:
                    agregarProducto(); 
                    break;
                case 2:
                    bodega.listarProductos(); 
                    break;
                case 3:
                    agregarStock(); 
                    break;
                case 4:
                    restarStock(); 
                    break;
                case 5:
                    salir = true; // bucle se detiene ya que se cambia a true
                    break;
                default:
                    System.out.println("OPCION INCORRECTA."); 
                    break;
            }
        }

        
        System.out.println("Apagando El Sistema...");
    }

    private void agregarProducto() {
        System.out.print("Codigo del producto: "); 
        String cod = sc.nextLine(); 
        System.out.print("Nombre: "); 
        String nom = sc.nextLine(); 
        System.out.print("Stock inicial: "); 
        int stock = sc.nextInt(); 
        System.out.println("---------------------");
        bodega.agregarProducto(cod, nom, stock); // Llama al metodo de la bodega para agregar el producto
        System.out.println("---------------------");
    }

    
    private void agregarStock() {
        System.out.print("Codigo del producto: "); 
        String cod = sc.nextLine(); 
        System.out.print("Cantidad a agregar: "); 
        int cant = sc.nextInt(); 
        bodega.Agregar(cod, cant); 
    }

 
    private void restarStock() {
        System.out.print("Codigo: "); 
        String cod = sc.nextLine(); 
        System.out.print("Cantidad a vender: "); 
        int cant = sc.nextInt(); 
        bodega.restar(cod, cant); 
    }
}